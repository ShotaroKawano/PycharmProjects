from lesson_package.tools import utils
# from ..tools import utils

def sing():
    return '#fjslafjlakj'

def cry():
    # return 'cry'
    return utils.say_twice('sjflajflsakj')